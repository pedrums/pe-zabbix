#!/usr/bin/perl -w
 
my $first = 1;
my $user;
 
print "[\n";
 
foreach $user (`ps --no-headers  -eo user`)
{
   $user_map{$user}=1
}

foreach $user  (sort keys %user_map) {
 
	print ",\n" if not $first;
	$first = 0;
        chomp($user) ;
	print "{\n";
	print "\"\{#PSUSER\}\":\"$user\"";
	print "}";
}
 
print "]\n";
